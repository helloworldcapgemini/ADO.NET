﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_ENTITY
{
    public class Employee
    {
        public int Id { get; set; }
        public String FullName { get; set; }
        public decimal Salary { get; set; }
        public DateTime DOJ { get; set; }
        public int DeptId { get; set; }
    }
}
