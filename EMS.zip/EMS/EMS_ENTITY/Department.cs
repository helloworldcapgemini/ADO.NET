﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_ENTITY
{
    class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
