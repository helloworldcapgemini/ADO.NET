﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ems_DAL;
using Ems_Exception;
using EMS_ENTITY;
namespace Ems_BAL
{
    public class EMSBAL
    {
        EMSDAL dal = null;
        public EMSBAL(string strcon)
        {
            dal = new EMSDAL(strcon);
        }
        public bool Add(Employee emp)
        {
            bool isSuccess = false;
            try
            {
                dal.Insert(emp);
                isSuccess = true;
            }
            catch (Ems_exception ex)
            {
                throw ex;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return isSuccess;
        }
        public bool Modify(Employee emp)
        {
            bool isSuccess = false;
            try
            {
                dal.update(emp);
                isSuccess = true;
            }
            catch (Ems_exception ex)
            {
                throw ex;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return isSuccess;
        }
        public bool remove(int empid)
        {
            bool isSuccess = false;
            try
            {
                dal.Delete(empid);
                isSuccess = true;
            }
            catch (Ems_exception ex)
            {
                throw ex;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return isSuccess;
        }
        public List<Employee> GetAll()
        {

            List<Employee> emps = null;
            try
            {
                emps = dal.SelectAll();

            }
            catch (Ems_exception ex)
            {
                throw ex;
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            return emps;
        }
    }
}
