﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using EMS_ENTITY;
using Ems_Exception;
namespace Ems_DAL
{
    public class EMSDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public EMSDAL(string constring)
        {
            cn = new SqlConnection(constring);
        }
        public bool Insert(Employee emp)
        {
            bool isinsert = false;
            try
            {
               
                cmd = new SqlCommand("Insert into Emplo_138281(FullName,Salary,DeptId,DOJ)values(@FullName,@Salary,@DeptId,@DOJ)", cn);
                cmd.Parameters.AddWithValue("@FullName", emp.FullName);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@DeptId", emp.DeptId);
                cmd.Parameters.AddWithValue("@DOJ", emp.DOJ);
                cn.Open();
                cmd.ExecuteNonQuery();
                isinsert = true;
            }

            catch(Ems_exception ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return isinsert;
        }

        public bool update(Employee emp)
        {
            bool isupdate = false;
            try
            {

                cmd = new SqlCommand("Update emplo_138281 set FullName=@FullName,Salary=@Salary,DeptId=@DeptId,DOJ=@DOJ where id=@Id", cn);
                cmd.Parameters.AddWithValue("@Id", emp.Id);
                cmd.Parameters.AddWithValue("@FullName", emp.FullName);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@DeptId", emp.DeptId);
                cmd.Parameters.AddWithValue("@DOJ", emp.DOJ);
                cn.Open();
                cmd.ExecuteNonQuery();
                isupdate = true;
            }

            catch (Ems_exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return isupdate;
        }

         public bool Delete(int empId)
        {
            bool isDelete = false;
            try
            {
                cmd = new SqlCommand("delete from emplo_138281 where id=@Id", cn);
                cmd.Parameters.AddWithValue("@Id", empId);
                cn.Open();
                cmd.ExecuteNonQuery();
                isDelete = true;
            }
            catch (Ems_exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
               cn.Close();
            }
            return isDelete;
        }
         public List<Employee> SelectAll()
         {
             List<Employee> emps = new List<Employee>();
             try
             {
                 cmd = new SqlCommand("select * from emplo_138281", cn);
                 cn.Open();
                 dr = cmd.ExecuteReader();
                 while (dr.Read())
                 {
                     Employee emp = new Employee();
                     emp.Id = Convert.ToInt32(dr["Id"]);
                     emp.FullName = dr["FullName"].ToString();
                     emp.Salary = Convert.ToDecimal(dr["Salary"]);
                     emp.DeptId = Convert.ToInt32(dr["DeptId"]);
                    // emp.DOJ = DateTime.ParseExact(dr["DOJ"].ToString(),"MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                     emp.DOJ = (DateTime)dr["DOJ"];
                     emps.Add(emp);
                 }

             }
             catch (Ems_exception ex)
             {
                 throw ex;
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             finally
             {
                 dr.Close();
                 cn.Close();
             }
             return emps;
         }  

    }
}
