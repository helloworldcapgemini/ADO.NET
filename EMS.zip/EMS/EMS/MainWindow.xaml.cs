﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Ems_BAL;
using EMS_ENTITY;
using Ems_Exception;
using System.Configuration;
using System.Configuration.Install;
namespace EMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EMSBAL bal = null;

        public MainWindow()
        {
            InitializeComponent();
            bal = new EMSBAL(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
            PopulateUI();
        }
        List<Employee> emps = new List<Employee>();
        
       
        public void PopulateUI()
        {
            try
            {
                dgEmps.ItemsSource = bal.GetAll();
                cbEmpIds.ItemsSource = bal.GetAll();
                cbEmpIds.SelectedValuePath = "Id";
                //cbEmpIds.DisplayMemberPath = "FullName";
                cbEmpIds.DisplayMemberPath = "Id";
            }
            catch(Ems_exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee();
            emp.FullName = txtFullName.Text;
            emp.Salary = decimal.Parse(txtSalary.Text);
            emp.DeptId = int.Parse(txtDeptId.Text);
            emp.DOJ = DateTime.Parse(txtDoj.Text);
            try
            {
                if (bal.Add(emp))
                {
                    MessageBox.Show("Added !!!");
                    PopulateUI();
                }
            }
            catch (Ems_exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee();
            emp.Id = int.Parse(cbEmpIds.SelectedValue.ToString());
            emp.FullName = txtFullName.Text;
            emp.Salary = decimal.Parse(txtSalary.Text);
            emp.DeptId = int.Parse(txtDeptId.Text);
            emp.DOJ = DateTime.Parse(txtDoj.Text);
            //code to read data from controls & assign to employee object
            try
            {
                if(bal.Modify(emp))
                {
                    MessageBox.Show("Updated !!!");
                    PopulateUI();
                }
            }
            catch(Ems_exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(cbEmpIds.SelectedValue.ToString());
            try
            {
                if(bal.remove(id))
                {
                    MessageBox.Show("deleted !!!");
                    PopulateUI();
                }
            }
            catch (Ems_exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        

        private void cbEmpIds_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Employee emp=null;
            foreach (var item in emps)
	        {
		        if(item.Id==int.Parse(cbEmpIds.SelectedValue.ToString()))
                {
                    emp=item;
                }
	        }
            this.DataContext = emp;
        }
    }
}
