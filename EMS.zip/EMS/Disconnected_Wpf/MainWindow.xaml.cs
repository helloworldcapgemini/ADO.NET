﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using EMS_ENTITY;
namespace Disconnected_Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DataSet ds = null;
        SqlDataAdapter da = null;

        SqlConnection cn = null;
        //SqlCommand cmd = null;
        //SqlDataReader dr = null;
        
        public MainWindow()
        {
            InitializeComponent();
            cn=new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_20Sep17_Pune_Batch_I;User ID=sqluser;Password=sqluser");
        }
        public void FillDataSet()
        {
           // cmd = new SqlCommand("Select * from Emplo_138281", cn);
            da = new SqlDataAdapter("Select * from Emplo_138281",cn);
            ds = new DataSet();
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
          
            MessageBox.Show("Before Fill:ds.tables.count" + ds.Tables.Count.ToString());
            da.Fill(ds,"emp1");
            MessageBox.Show("after Fill:ds.tables.count" + ds.Tables.Count.ToString());
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            DataRow row = ds.Tables["emp1"].NewRow();
            row["FullName"] = txtFullName.Text;
            row["Salary"] = decimal.Parse(txtSalary.Text);
            row["DeptId"] = int.Parse(txtDeptId.Text);
            row["DOJ"] = DateTime.Parse(txtDoj.Text);

            ds.Tables["emp1"].Rows.Add(row);
            MessageBox.Show("Added !!!!");
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            SqlCommandBuilder cmdBuilder = new SqlCommandBuilder(da);
            da.Update(ds, "emp1");
            MessageBox.Show("Updated !!!!");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DataRow row = ds.Tables["emp1"].Rows.Find(101);
            ds.Tables["emp1"].Rows.Remove(row);
            MessageBox.Show("Deleted !!!!");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FillDataSet();
            List<Employee> emps = new List<Employee>();
            Employee emp = new Employee();
            foreach (DataRow row in ds.Tables["emp1"].Rows)
            {
                emp.FullName = (string)row["FullName"];
                emp.Salary=(decimal) row["Salary"];
                emp.DeptId=(int) row["DeptId"];
                emp.DOJ=(DateTime)row["DOJ"];
                emps.Add(emp);
            }
            dgEmps.ItemsSource=emps;
            cbEmpIds.ItemsSource = emps;
            cbEmpIds.SelectedValuePath = "Id";
            //cbEmpIds.DisplayMemberPath = "FullName";
            cbEmpIds.DisplayMemberPath = "Id";
            //dgEmps.ItemsSource = ds.Tables["emp1"];
        }

        private void cbEmpIds_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
